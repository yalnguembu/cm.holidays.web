<template>
  <RouterView/>
</template>

<script lang="ts" setup>
import ThePageLayout from "./components/ThePageLayout.vue";
</script>

import { defineStore } from "pinia";
import { Post, newNullPost } from "@/domain/Post";
import {PostService} from "@/services";
import {services} from "../../cypress/utils/data";

export const usePostStore = defineStore("post", () => {
  const getAllPosts = async (): Promise<Post[]> => {
    try {
      const posts =[
        {
          "id": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
          "name": "DevOps",
          "description": "permet la coordination et la collaboration des rôles autrefois cloisonnés (développement, opérations informatiques, ingénierie qualité et sécurité) pour créer des produits plus performants et plus fiables",
          "service": services[0],
          "isActive": true,
          "createdAt": "2023-09-29T14:54:38.926Z",
          "updatedAt": "2023-09-29T14:54:38.926Z"
        },
        {
          "id": "2c963f66afa6-5717-4562-b3fc-2c963f66afa6",
          "name": "UI Designer",
          "description": "La conception d'interface utilisateur ou l'ingénierie d'interface utilisateur est la conception d'interfaces utilisateur pour des machines et des logiciels, tels que des ordinateurs, des appareils",
          "service": services[1],
          "isActive": true,
          "createdAt": "2023-09-29T14:54:38.926Z",
          "updatedAt": "2023-09-29T14:54:38.926Z"
        },
        {
          "id": "3fa85f64-5717-4562-5717-2c963f66afa6",
          "name": "Sale Manager",
          "description": "permet la coordination et la collaboration des rôles autrefois cloisonnés (développement, opérations informatiques, ingénierie qualité et sécurité) pour créer des produits plus performants et plus fiables",
          "service": services[2],
          "isActive": false,
          "createdAt": "2023-09-29T14:54:38.926Z",
          "updatedAt": "2023-09-29T14:54:38.926Z"
        },
        {
          "id": "2c963f66afa6-4562-4562-b3fc-3fa85f64",
          "name": "Comptable",
          "description": "La conception d'interface utilisateur ou l'ingénierie d'interface utilisateur est la conception d'interfaces utilisateur pour des machines et des logiciels, tels que des ordinateurs, des appareils",
          "service": services[1],
          "isActive": true,
          "createdAt": "2023-09-29T14:54:38.926Z",
          "updatedAt": "2023-09-29T14:54:38.926Z"
        },
      ] //await PostService.getAllPosts();
      return posts.map((post) => new Post(post));
    } catch (error: unknown) {
      console.log(error);
      return [];
    }
  };
  const getPostById = async (postId: string): Promise<Post> => {
    try {
      const post = await PostService.getPostById({id:postId});
      return new Post(post);
    } catch (error: unknown) {
      console.log(error);
      return newNullPost();
    }
  };

  const createPost = async (post: Post): Promise<void> => {
    try {
      await PostService.createPost({requestBody: post.postAsDTO});
    } catch (error: unknown) {
      console.log(error);
    }
  };

  const activatePostById = async (postId:string): Promise<void> => {
    try {
      await PostService.activatePostById({id:postId});
    } catch (error: unknown) {
      console.log(error);
    }
  }

  const deactivatePostById = async (postId:string): Promise<void> => {
    try {
      await PostService.deactivatePostById({id:postId});
    } catch (error: unknown) {
      console.log(error);
    }
  }


  const updatePost = async (post: Post): Promise<void> => {
    try {
      await PostService.updatePost({id: post.id, requestBody: post.postAsDTO});
    } catch (error: unknown) {
      console.log(error);
    }
  };

  return {
    getAllPosts,
    getPostById,
    createPost,
    activatePostById,
    deactivatePostById,
    updatePost
  };
});

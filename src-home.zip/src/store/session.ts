import {defineStore} from "pinia";
import {EmployeeService, USER_ROLE} from "@/services";
import {newNullSession, Session} from "@/domain/Session";
import {ref} from "vue"
import {Credential} from "@/domain/Credential";
import {storeUserInformationsInsideStorage} from "@/utils/api";

export const useSessionStore = defineStore("employee", () => {

    // const session = ref<Session>(newNullSession())
    const session = ref<Session>(new Session({
        email:"yal@holiday.cm",
        id: "1234-1234-1234-1234",
        firstname:"Fucker",
        lastName:"Mother's",
        roles:[{
            type : USER_ROLE["ADMIN"],
            description: "",
            id: "1234"
        }],
        posts: [
            {
                id: "1234",
                name: "Frontend Dev",
            },
            {
                id: "1234",
                name: "UI/UX Designer",
            }
        ],
    }))

    const login = async (credential: Credential): Promise<{success:boolean}> => {
        try {
            const authenticationResponse = await EmployeeService.authenticateEmployee({requestBody: credential.credentialAsDTO});
            session.value = new Session({
                id: authenticationResponse.id,
                email: credential.email,
            });
            storeUserInformationsInsideStorage(authenticationResponse)
            return {success:true}
        } catch (error: unknown) {
            console.log(error);
            return {success: false}
        }
    };

    const getUserInformations = async (id: string): Promise<{success:boolean}> =>{
        try {
            const informations = await  EmployeeService.getEmployeeById({id})
            session.value = new Session(informations)
            return { success:true };
        }
        catch (error: unknown) {
            console.error(error)
            return { success:false };
        }
    }

    const signOut = () =>{
        session.value = newNullSession();
        localStorage.clear();
    }

    const isLoggedIn = ref<boolean>(!session.value.isNull)

    return {
        login,
        session,
        isLoggedIn,
        getUserInformations,
        signOut
    };
});

import {UserInformation} from "@/utils/types";

export const storeUserInformationsInsideStorage = (informations: UserInformation):void=>{
    localStorage.setItem("user-informations", JSON.stringify(informations));
}

export const getUserInformationsInsideStorage = ():UserInformation=>{
  const informations :string =  localStorage.getItem("user-informations") ?? "{}";
  return JSON.parse(informations);
}

export const prepareApis = (): void =>{

}
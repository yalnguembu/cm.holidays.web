/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type EmployeeDTOForLogin = {
    /**
     * employee email
     */
    email?: string;
    /**
     * user password
     */
    password?: string;
};


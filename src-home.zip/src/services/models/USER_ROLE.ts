/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export enum USER_ROLE {
    ADMIN = 'ADMIN',
    EMPLOYEE = 'EMPLOYEE',
    HUMAN_RESOURCE = 'HUMAN_RESOURCE',
}

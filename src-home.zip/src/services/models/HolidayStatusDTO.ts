/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export enum HolidayStatusDTO {
    DRAFT = 'DRAFT',
    PENDING = 'PENDING',
    APPROVED = 'APPROVED',
    REJECTED = 'REJECTED',
}

/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type EmployeeTokenDTO = {
    /**
     * identifier the user id
     */
    id?: string;
    /**
     * token use to have access to all operations need inside
     */
    token?: string;
};


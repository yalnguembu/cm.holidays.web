/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export enum PERMISSIONS {
    EMPLOYEE_CREATE = 'employee:create',
    EMPLOYEE_READ = 'employee:read',
    EMPLOYEE_EDIT = 'employee:edit',
}

<template>
  <div class="w-full bounce border rounded-xl p-4 shadow-[1px_35px_5px_-19px_#D1E4FA] bg-white h-full animate-pulse">
    <div class="flex justify-between items-center">
      <div class="w-24 bg-gray-200 h-1.5" />
      <div class="rouded rounded-full px-2 py-2 bg-gray-100">
        <div class="w-32 bg-gray-200 h-1.5" />
      </div>
    </div>
    <div class="w-80 bg-gray-200 h-6 mt-6" />
    <div class="w-24 bg-gray-200 rounded-full h-8 my-8" />
    <div class="w-full bg-gray-200 h-3" />
    <div class="w-full bg-gray-200 h-3 mt-3" />
    <div class="w-full bg-gray-200 h-3 mt-3" />
    <div class="w-80 bg-gray-200 h-3 mt-3" />
    <div class="w-32 bg-gray-200 h-3 mt-3" />
  </div>
</template>

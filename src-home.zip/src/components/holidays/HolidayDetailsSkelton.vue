<template>
  <div class="w-full bounce animate-pulse">
    <div class="w-24 bg-gray-100 h-4" />
    <div class="w-32 bg-gray-100 h-2 mt-8" />
    <div class="w-80 bg-gray-100 h-6 mt-2" />
    <div class="w-32 bg-gray-100 h-2 mt-4" />
    <div class="w-24 bg-gray-100 rounded-full h-8 my-6" />
    <div class="w-full bg-gray-100 h-3 mt-3" />
    <div class="w-full bg-gray-100 h-3 mt-3" />
    <div class="w-full bg-gray-100 h-3 mt-3" />
    <div class="w-80 bg-gray-100 h-3 mt-3" />
    <div class="w-32 bg-gray-100 h-3 mt-3" />
  </div>
</template>

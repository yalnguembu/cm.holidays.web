<template>
  <div class="w-full text-center p-4 bg-white shadow-lg">
    <h2 class="text-3xl font-bold">Holidays</h2>
  </div>
</template>

<template>
  <div class="w-full shadow-md flex justify-center">
    <nav
      data-test="nav-bar"
      :class="[
        'w-full flex items-center px-8 bg-white md:px-5 md:px-12 xl:max-w-[98vw] 2xl:max-w-[95vw]',
        user.isNull ? 'justify-center' : 'justify-between',
      ]"
    >
      <RouterLink to="/" class="text-xl font-bold text-blue-500"
        >HOLIDAYS</RouterLink
      >
      <div class="flex items-center">
        <ul class="flex">
          <li
            v-for="(item, index) in items"
            :key="index"
            :data-test="`nav-${index}`"
            class="relative overflow-hidden transition"
          >
            <RouterLink
              :to="item.path"
              :class="[
                'block px-4 p-4 mx-2 font-semibold text-lg hover:text-blue-300',
                isTheActiveRoute(item.name)
                  ? 'text-blue-primary'
                  : 'text-gray-500',
              ]"
              >{{ item.label }}</RouterLink
            >
            <div
              class="absolute w-full -bottom-1 left-0 bg-blue-primary transition p-1 rounded-full"
              v-if="isTheActiveRoute(item.name)"
            />
          </li>
        </ul>
      </div>
      <div class="relative" v-if="!user.isNull">
        <button
          class="flex items-center hover:bg-gray-100 py-2 px-4 rounded-lg"
          @click.stop="toggleIsShouldDisplayProfileOverviewModal"
        >
          <AccountIcon class="cursor-pointer h-8 w-8" />
          <span class="font-bold text-base ml-2 text-gray-500">{{
            user.fullName
          }}</span>
        </button>
        <UserProfile
          :user="user"
          v-if="shouldDisplayProfileOverviewModal"
          @close="toggleIsShouldDisplayProfileOverviewModal"
          @signOut="displaySignOutModal"
        />
      </div>
      <ConfirmationModal
        title="Sign Out"
        description="Are you sure that you realy want tot sign out?, after click on this button your will be redirected to the login page"
        v-if="shouldDisplaySignOutModal"
        @confirm="signOut"
        @close="shouldDisplaySignOutModal = false"
      />
    </nav>
  </div>
</template>

<script setup lang="ts">
import { PropType, ref } from "vue";
import AccountIcon from "./icons/AccountIcon.vue";
import UserProfile from "./modals/UserProfileModal.vue";
import type { NavaBarItem } from "@/utils/menu";
import { Session } from "@/domain/Session";
import { useRoute } from "vue-router";
import ConfirmationModal from "@/components/modals/ConfirmationModal.vue";
import { useSessionStore } from "@/store/session";
import router from "@/router";

defineProps({
  items: {
    type: Array as PropType<Array<NavaBarItem>>,
  },
  user: {
    type: Object as PropType<Session>,
    required: true,
  },
});

const isTheActiveRoute = (route: string): boolean => useRoute().name === route;
const shouldDisplayProfileOverviewModal = ref<boolean>(false);

const toggleIsShouldDisplayProfileOverviewModal = (): void => {
  shouldDisplayProfileOverviewModal.value =
    !shouldDisplayProfileOverviewModal.value;
};

const shouldDisplaySignOutModal = ref<boolean>(false);

const signOut = async () => {
  useSessionStore().signOut();
  shouldDisplaySignOutModal.value = false;
  await router.push("/auth/sign-in");
};

const displaySignOutModal = (): void => {
  toggleIsShouldDisplayProfileOverviewModal();
  shouldDisplaySignOutModal.value = true;
};
</script>

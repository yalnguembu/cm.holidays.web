<template>
  <div
    class="md:shadow-lg md:border md:bg-white md:p-5 lg:p-8 rounded-lg md:w-1/2 mx-auto md:mt-8 xl:w-1/3"
  >
    <slot />
  </div>
</template>

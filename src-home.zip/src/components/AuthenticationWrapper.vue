<template>
  <AuthenticationNavbar />
  <RouterView />
</template>
<script setup lang="ts">
import AuthenticationNavbar from "./AuthenticationNavbar.vue";
</script>

<template>
  <ModalWrapper @close="$emit('close')">
    <form
      data-test="post-creation-form"
      @submit.prevent="create"
      class="w-92 border rounded-xl p-6 shadow-lg bg-white"
    >
      <div>
        <h2 class="text-2xl font-bold text-center mb-4" data-test="form-title">
          New Post
        </h2>
      </div>
      <TextField
        label="Title"
        data-test="holiday-type"
        placeholder="Enter a title for the post"
        v-model="post.title"
        :error="error.title"
      />
      <SelectInput
        class="mt-3"
        data-test="holiday-type"
        label="Service"
        placeholder="Select a service"
        :options="services"
        v-model="post.service"
        :error="error.service"
      />
      <TextArea
        placeholder="Enter the description"
        label="Description"
        v-model="post.description"
        :error="error.description"
      />
      <div class="grid md:grid-cols-2 mt-3 gap-x-4">
        <BaseButton
          @click="$emit('close')"
          title="cancel"
          data-test="submit-button"
          class="w-full shadow-none text-base mt-4 hover:shadow-md bg-blue-100 font-semibold text-gray-700 md:mt-0"
        />
        <BaseButton
          title="Create"
          :disabled="!shouldCreationButtonEnable"
          data-test="submit-button"
          @click="create"
          :class="[
            'w-full shadow-none text-base mt-4 font-semibold md:mt-0',
            shouldCreationButtonEnable
              ? 'bg-blue-primary/100 hover:shadow-blue-primary hover:shadow-md cursor-pointer'
              : ' bg-blue-primary/40 cursor-not-allowed',
          ]"
        />
      </div>
    </form>
  </ModalWrapper>
</template>

<script setup lang="ts">
import BaseButton from "../BaseButton.vue";
import TextArea from "@/components/forms/TextArea.vue";
import TextField from "@/components/forms/TextField.vue";
import SelectInput from "@/components/forms/SelectInput.vue";
import { reactive, computed, ref, onBeforeMount } from "vue";
import ModalWrapper from "../modals/ModalWrapper.vue";
import { HolidayErrors } from "@/utils/type";
import { useServiceStore } from "@/store/service";
import { Service } from "@/domain/Service";

const emit = defineEmits<{
  (event: "close"): void;
  (event: "created"): void;
}>();

const isProcessing = ref<boolean>(false);
const isLoadingServices = ref<boolean>(false);
const services = ref<Service[]>([]);

const fetchServices = async ():Promise<void> => {
  isLoadingServices.value = true;
  services.value = await useServiceStore().getAllServices();
  isLoadingServices.value = false;
};

onBeforeMount(() => {
  fetchServices();
});
const post = reactive({
  title: "",
  description: "",
  service: "",
});

const shouldCreationButtonEnable = computed(
  () => !!post.title && !!post.service && !isProcessing.value
);
const error = reactive<HolidayErrors>({
  title: "",
  description: "",
  service: "",
});

const create = () => {
  emit("created");
};
const close = (): void => {
  emit("close");
};
</script>

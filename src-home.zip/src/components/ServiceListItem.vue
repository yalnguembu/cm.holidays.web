<template>
  <div
    :data-test="`service-${service.id}`"
    class="border p-6 rounded-lg h-42 overflow-hidden hover:bg-gray-100/30 cursor-pointer hover:shadow-lg relative group"
  >
    <h4 class="text-blue-900 font-semibold text-2xl mb-4">
      {{ service.name }}
    </h4>
    <p class="text-gray-500 text-sm line-clamp-3">
      {{ service.description }}
    </p>
    <ListItemOption
      :isActive="service.isActive"
      @edit="toggleEditionFormVisibility"
      @delete="toggleShouldDeleteService"
      @disactivate="toggleShouldDisactivateService"
      @activate="toggleShouldActivateService"
    />
  </div>
  <ServiceEdition
    data-test="service-edition-modal"
    :service="service"
    v-if="shouldEditService"
    @cancel="toggleEditionFormVisibility"
    @edited="$emit('update')"
  />
  <ConfirmationModal
    data-test="service-delete-modal"
    title="Delete Service"
    :description="`By click on the confirm button the service will ${service.name} be deleted are you agree`"
    :theme="COLOR_THEME.RED"
    @close="toggleShouldDeleteService"
    @confirm="toggleShouldDeleteService"
    v-if="shouldDeleteService"
    :isLoading="isLoading"
  />
  <ConfirmationModal
    data-test="service-activation-modal"
    title="Activate Service"
    :description="`By click on the confirm button the service ${service.name} will be activate are you agree`"
    @close="toggleShouldActivateService"
    @confirm="toggleShouldActivateService"
    v-if="shouldActivateService"
    :isLoading="isLoading"
  />
  <ConfirmationModal
    data-test="service-disactivation-modal"
    title="Disactivate Service"
    :theme="COLOR_THEME.RED"
    :description="`By click on the confirm button the service will ${service.name} be disactivate are you agree`"
    @close="toggleShouldDisactivateService"
    @confirm="toggleShouldDisactivateService"
    v-if="shouldDisactivateService"
    :isLoading="isLoading"
  />
</template>
<script lang="ts" setup>
import ConfirmationModal from "@/components/modals/ConfirmationModal.vue";
import ServiceEdition from "@/components/modals/ServiceEdition.vue";
import { PropType, ref } from "vue";
import { Service } from "@/domain/Service";
import ListItemOption from "@/components/ListItemOption.vue";
import { COLOR_THEME } from "@/utils/enum";

defineProps({
  service: {
    type: Object as PropType<Service>,
  },
});

defineEmits(["update"]);

const isLoading = ref<boolean>(false);
const isRequesting = ref<boolean>(false);
const isRequested = ref<boolean>(false);

const shouldEditService = ref<boolean>(false);
const toggleEditionFormVisibility = () =>
  (shouldEditService.value = !shouldEditService.value);

const shouldDeleteService = ref<boolean>(false);
const toggleShouldDeleteService = () =>
  (shouldDeleteService.value = !shouldDeleteService.value);

const shouldActivateService = ref<boolean>(false);
const toggleShouldActivateService = () =>
  (shouldActivateService.value = !shouldActivateService.value);

const shouldDisactivateService = ref<boolean>(false);
const toggleShouldDisactivateService = () =>
  (shouldDisactivateService.value = !shouldDisactivateService.value);
</script>
